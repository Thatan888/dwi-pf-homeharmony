<header class="p-3 text-white" style="background-color: #53ACAF;">
    <div class="container">
        <div class="d-flex flex-wrap align-items-center justify-content-center justify-content-lg-start">
            <a>
                <img src="<?php echo e(url('images/Logo HomeHarmony Azul.png')); ?>" alt="Logo" style="height: 100px" />
            </a>

            <a href="/" class="d-flex align-items-center mb-2 mb-lg-0 text-white text-decoration-none">
                <svg class="bi me-2" width="40" height="32" role="img" aria-label="Bootstrap">
                    <use xlink:href="#bootstrap" />
                </svg>
            </a>

            <ul class="nav col-12 col-lg-auto me-lg-auto mb-2 justify-content-center mb-md-0">
                <li><a href="<?php echo e(route('home.app')); ?>" class="nav-link px-2 fw-bold text-secondary">Home</a></li>
            </ul>



            <?php if(auth()->guard()->check()): ?>
            <ul class="nav col-12 col-lg-auto me-lg-auto mb-2 justify-content-center mb-md-0">
                <li><a href="<?php echo e(route('articles.index')); ?>" class="nav-link fw-bold px-2 text-white">Articles</a></li>
                <li><a href="<?php echo e(route('categories.index')); ?>" class="nav-link fw-bold px-2 text-white">Categories</a></li>
            </ul>
            <div class="d-flex align-items-center fw-bold">
                <span class="text-white me-3"><?php echo e(auth()->user()->name); ?></span>
                <a href="<?php echo e(route('logout.perform')); ?>" class="btn btn-outline-light">Logout</a>
            </div>
        <?php endif; ?>


            <?php if(auth()->guard()->guest()): ?>
                <div class="text-end">
                    <a href="<?php echo e(route('login.perform')); ?>" class="btn btn-outline-light me-2">Login</a>
                    <a href="<?php echo e(route('register.perform')); ?>" class="btn btn-warning">Sign-up</a>
                </div>


            <?php endif; ?>
        </div>
    </div>
</header>

<?php /**PATH C:\Universidad\UTOM\dwi-pf-homeharmony\resources\views/layouts/partials/navbar.blade.php ENDPATH**/ ?>