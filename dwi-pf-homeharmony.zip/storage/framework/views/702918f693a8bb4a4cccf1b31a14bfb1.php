<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

<head>
    <meta charset="UTF-8">
    <title>Home</title>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Built with Blueprints app">
    <meta name="author" content="Bootstraptor.com">
    <link rel="icon" href="favicon.ico">

    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/all.css">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">

    <style>
        .bg-overlay {
            background: rgba(0, 0, 0, .7);
            position: absolute;
            top: 0;
            bottom: 0;
            left: 0;
            right: 0;
            z-index: 0;
        }

        /* From Uiverse.io by barisdogansutcu */
        button {
            padding: 17px 40px;
            border-radius: 50px;
            cursor: pointer;
            border: 0;
            background-color: white;
            box-shadow: rgb(0 0 0 / 5%) 0 0 8px;
            letter-spacing: 1.5px;
            text-transform: uppercase;
            font-size: 15px;
            transition: all 0.5s ease;
        }

        button:hover {
            letter-spacing: 3px;
            background-color: hsl(261deg 80% 48%);
            color: hsl(0, 0%, 100%);
            box-shadow: rgb(93 24 220) 0px 7px 29px 0px;
        }

        button:active {
            letter-spacing: 3px;
            background-color: hsl(261deg 80% 48%);
            color: hsl(0, 0%, 100%);
            box-shadow: rgb(93 24 220) 0px 0px 0px 0px;
            transform: translateY(10px);
            transition: 100ms;
        }
    </style>
</head>

<body>
    <section class="pt-5 pb-5 bg-dark position-relative"
        style="min-height:100vh; background-image: url(images/muebles.jpg); background-size: cover;">
        <div class="bg-overlay"></div>
        <div class="container pt-5 pb-5 position-relative">
            <div class="row d-flex justify-content-between pt-lg-5 align-items-center">
                <div class="col-xl-5 col-lg-6 col-md-7 text-center text-lg-left mb-5 mb-lg-0">
                    <h1 class="display-3 font-weight-bold text-white aos-init aos-animate" data-aos="fade-up">
                        The best online store to purchase your furniture
                    </h1>
                    <div class="my-4 aos-init" data-aos="fade-up">
                        <p class="lead text-white text-justify">
                            Discover a wide range of furniture that perfectly matches your taste and style. Whether
                            you're looking for cozy comfort or modern elegance, we have it all to transform your space
                            into a dream home!
                        </p>
                    </div>
                    <div class="d-flex justify-content-center justify-content-lg-start aos-init" data-aos="fade-up">
                        <div class="d-flex mr-2">
                            <i class="fas fa-star fa-lg text-warning m-1"></i>
                            <i class="fas fa-star fa-lg text-warning m-1"></i>
                            <i class="fas fa-star fa-lg text-warning m-1"></i>
                            <i class="fas fa-star fa-lg text-warning m-1"></i>
                            <i class="fas fa-star fa-lg text-warning m-1"></i>
                        </div>
                        <span class="text-white">(Average score: 4.9/5)</span>
                    </div>
                </div>
                <div class="col">
                    <div class="row justify-content-center text-center">
                        <div class="col-xl-8 col-md-10">
                            <img class="d-block img-fluid rounded-circle pb-3"
                                src="<?php echo e(url('images/Logo HomeHarmony.png')); ?>" alt="user">
                            <button class="button" onclick="window.location.href='<?php echo e(route('home.app')); ?>'">
                                Go to the App
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <section class="pt-5 pb-5 bg-light">
        <div class="container pt-5 pb-5">
            <div class="row d-flex justify-content-between">
                <div class="col-md-3 aos-init" data-aos="fade-up">
                    <div class="card">
                        <img src="imagesArticles/tables.jpg" class="card-img-top" alt="Tables View">
                        <div class="card-body">
                            <h5 class="card-title text-center">Tables</h5>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 aos-init" data-aos="fade-up">
                    <div class="card">
                        <img src="imagesArticles/camas y tocadores.jpg" class="card-img-top"
                            alt="Beds and Dressing tables">
                        <div class="card-body">
                            <h5 class="card-title text-center">Beds and Dressing Tables</h5>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 aos-init" data-aos="fade-up">
                    <div class="card">
                        <img src="imagesArticles/sillones.jpg" class="card-img-top" alt="Armchairs">
                        <div class="card-body">
                            <h5 class="card-title text-center">Armchairs</h5>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 aos-init" data-aos="fade-up">
                    <div class="card">
                        <img src="imagesArticles/comedores.jpg" class="card-img-top" alt="Canteens">
                        <div class="card-body">
                            <h5 class="card-title text-center">Canteens</h5>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <!-- jQuery is required -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.2/js/bootstrap.min.js"></script>
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script>
        AOS.init({
            duration: 1200,
        })
    </script>


</body>
<?php /**PATH C:\Users\Yonatan\Documents\Universidad\UTOM\dwi-pf-homeharmony\resources\views/start.blade.php ENDPATH**/ ?>