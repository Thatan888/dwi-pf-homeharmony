<?php $__env->startSection('content'); ?>

<?php if($message = Session::get('success')): ?>
<div class="alert alert-success">
    <?php echo e($message); ?>

</div>
<?php endif; ?>

<div class="card">
    <div class="card-header">
        <div class="row">
            <div class="col col-md-6"><b>Furniture Categories Data</b></div>
            <div class="col col-md-6">
                <a href="<?php echo e(route('categories.create')); ?>" class="btn btn-success btn-sm float-end">Add</a>
            </div>
        </div>
    </div>
    <div class="card-body">
        <table class="table table-bordered">
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Description</th>
                <th>Action</th>
            </tr>
            <?php if(count($categories) > 0): ?>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($category->id); ?></td>
                    <td><?php echo e($category->name); ?></td>
                    <td><?php echo e($category->description); ?></td>
                    <td>
                        <form method="post" action="<?php echo e(route('categories.destroy', $category->id)); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <div class="d-flex flex-column">
                                <a href="<?php echo e(route('categories.show', $category->id)); ?>" class="btn btn-primary btn-sm mb-1">View</a>
                                <a href="<?php echo e(route('categories.edit', $category->id)); ?>" class="btn btn-warning btn-sm mb-1">Edit</a>
                                <input type="submit" class="btn btn-danger btn-sm" value="Delete" />
                            </div>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <tr>
                    <td colspan="4" class="text-center">No Data Found</td>
                </tr>
            <?php endif; ?>
        </table>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Yonatan\Documents\Universidad\UTOM\dwi-pf-homeharmony\resources\views/categories/index.blade.php ENDPATH**/ ?>