<?php $__env->startSection('content'); ?>
<section class="h-100 bg-dark">
    <div class="container py-5 h-100">
        <div class="row d-flex justify-content-center align-items-center h-100">
            <div class="col">
                <div class="card card-registration my-4">
                    <div class="row g-0">
                        <div class="col-xl-6 d-none d-xl-block">
                            <img src="https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-registration/img4.webp"
                                alt="Sample photo" class="img-fluid"
                                style="border-top-left-radius: .25rem; border-bottom-left-radius: .25rem;" />
                        </div>
                        <div class="col-xl-6">
                            <div class="card-body p-md-5 text-black">
                                <h3 class="mb-5 text-uppercase">Register</h3>

                                <form method="post" action="<?php echo e(route('register.perform')); ?>">
                                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />

                                    <div class="form-group form-floating mb-3">
                                        <input type="text" class="form-control" name="name" value="<?php echo e(old('name')); ?>" placeholder="Name" required="required" autofocus>
                                        <label for="floatingName">Name</label>
                                        <?php if($errors->has('name')): ?>
                                            <span class="text-danger text-left"><?php echo e($errors->first('name')); ?></span>
                                        <?php endif; ?>
                                    </div>

                                    <div class="form-group form-floating mb-3">
                                        <input type="text" class="form-control" name="fatherlastname" value="<?php echo e(old('fatherlastname')); ?>" placeholder="Father´s Last Name" required="required" autofocus>
                                        <label for="floatingName">Father´s Last Name</label>
                                        <?php if($errors->has('fatherlastname')): ?>
                                            <span class="text-danger text-left"><?php echo e($errors->first('fatherlastname')); ?></span>
                                        <?php endif; ?>
                                    </div>

                                    <div class="form-group form-floating mb-3">
                                        <input type="text" class="form-control" name="motherlastname" value="<?php echo e(old('motherlastname')); ?>" placeholder="Mother Last Name" required="required" autofocus>
                                        <label for="floatingName">Mother´s Last Name</label>
                                        <?php if($errors->has('motherlastname')): ?>
                                            <span class="text-danger text-left"><?php echo e($errors->first('motherlastname')); ?></span>
                                        <?php endif; ?>
                                    </div>

                                    <div class="form-group form-floating mb-3">
                                        <input type="text" class="form-control" name="username" value="<?php echo e(old('username')); ?>" placeholder="Username" required="required" autofocus>
                                        <label for="floatingName">Username</label>
                                        <?php if($errors->has('username')): ?>
                                            <span class="text-danger text-left"><?php echo e($errors->first('username')); ?></span>
                                        <?php endif; ?>
                                    </div>

                                    <div class="form-group form-floating mb-3">
                                        <input type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" placeholder="name@example.com" required="required" autofocus>
                                        <label for="floatingEmail">Email address</label>
                                        <?php if($errors->has('email')): ?>
                                            <span class="text-danger text-left"><?php echo e($errors->first('email')); ?></span>
                                        <?php endif; ?>
                                    </div>

                                    <div class="form-group form-floating mb-3">
                                        <input type="password" class="form-control" name="password" value="<?php echo e(old('password')); ?>" placeholder="Password" required="required">
                                        <label for="floatingPassword">Password</label>
                                        <?php if($errors->has('password')): ?>
                                            <span class="text-danger text-left"><?php echo e($errors->first('password')); ?></span>
                                        <?php endif; ?>
                                    </div>

                                    <div class="form-group form-floating mb-3">
                                        <input type="password" class="form-control" name="password_confirmation" value="<?php echo e(old('password_confirmation')); ?>" placeholder="Confirm Password" required="required">
                                        <label for="floatingConfirmPassword">Confirm Password</label>
                                        <?php if($errors->has('password_confirmation')): ?>
                                            <span class="text-danger text-left"><?php echo e($errors->first('password_confirmation')); ?></span>
                                        <?php endif; ?>
                                    </div>

                                    <div class="pt-1 mb-4">
                                        <button type="submit" class="btn btn-warning btn-lg ms-2">Register</button>
                                        <a href="<?php echo e(route('home.index')); ?>" class="btn btn-secondary btn-lg ms-2">Back</a>
                                    </div>

                                    <?php echo $__env->make('auth.partials.copy', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Universidad\UTOM\dwi-pf-homeharmony\resources\views/auth/register.blade.php ENDPATH**/ ?>