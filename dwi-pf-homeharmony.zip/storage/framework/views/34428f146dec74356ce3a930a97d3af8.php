<?php $__env->startSection('content'); ?>
<section class="h-100">
    <div class="container py-5 h-100 d-flex justify-content-center align-items-center">
        <form method="post" action="<?php echo e(route('register.perform')); ?>" class="form">
            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />

            <div class="title">Register</div>

            <div class="input-group mb-3">
                <input type="text" class="input" name="name" value="<?php echo e(old('name')); ?>" placeholder="Name" required="required" autofocus>
                <?php if($errors->has('name')): ?>
                    <span class="text-danger text-left"><?php echo e($errors->first('name')); ?></span>
                <?php endif; ?>
            </div>

            <div class="input-group mb-3">
                <input type="text" class="input" name="fatherlastname" value="<?php echo e(old('fatherlastname')); ?>" placeholder="Father's Last Name" required="required" autofocus>
                <?php if($errors->has('fatherlastname')): ?>
                    <span class="text-danger text-left"><?php echo e($errors->first('fatherlastname')); ?></span>
                <?php endif; ?>
            </div>

            <div class="input-group mb-3">
                <input type="text" class="input" name="motherlastname" value="<?php echo e(old('motherlastname')); ?>" placeholder="Mother's Last Name" required="required" autofocus>
                <?php if($errors->has('motherlastname')): ?>
                    <span class="text-danger text-left"><?php echo e($errors->first('motherlastname')); ?></span>
                <?php endif; ?>
            </div>

            <div class="input-group mb-3">
                <input type="text" class="input" name="username" value="<?php echo e(old('username')); ?>" placeholder="Username" required="required" autofocus>
                <?php if($errors->has('username')): ?>
                    <span class="text-danger text-left"><?php echo e($errors->first('username')); ?></span>
                <?php endif; ?>
            </div>

            <div class="input-group mb-3">
                <input type="email" class="input" name="email" value="<?php echo e(old('email')); ?>" placeholder="Email address" required="required" autofocus>
                <?php if($errors->has('email')): ?>
                    <span class="text-danger text-left"><?php echo e($errors->first('email')); ?></span>
                <?php endif; ?>
            </div>

            <!-- Campo para fecha de nacimiento -->
            <div class="input-group mb-3">
                <input type="date" class="input" name="birthdate" value="<?php echo e(old('birthdate')); ?>" placeholder="Birthdate" required="required">
                <?php if($errors->has('birthdate')): ?>
                    <span class="text-danger text-left"><?php echo e($errors->first('birthdate')); ?></span>
                <?php endif; ?>
            </div>

            <!-- Campo para RFC -->
            <div class="input-group mb-3">
                <input type="text" class="input" name="rfc" value="<?php echo e(old('rfc')); ?>" placeholder="RFC" required="required" maxlength="13">
                <?php if($errors->has('rfc')): ?>
                    <span class="text-danger text-left"><?php echo e($errors->first('rfc')); ?></span>
                <?php endif; ?>
            </div>

            <div class="input-group mb-3">
                <input type="password" class="input" name="password" value="<?php echo e(old('password')); ?>" placeholder="Password" required="required">
                <?php if($errors->has('password')): ?>
                    <span class="text-danger text-left"><?php echo e($errors->first('password')); ?></span>
                <?php endif; ?>
            </div>

            <div class="input-group mb-3">
                <input type="password" class="input" name="password_confirmation" value="<?php echo e(old('password_confirmation')); ?>" placeholder="Confirm Password" required="required">
                <?php if($errors->has('password_confirmation')): ?>
                    <span class="text-danger text-left"><?php echo e($errors->first('password_confirmation')); ?></span>
                <?php endif; ?>
            </div>

            <div class="pt-1 mb-4 d-flex justify-content-between">
                <button type="submit" class="button-confirm">Register</button>
            </div>
            <div class="pt-1 mb-4 d-flex justify-content-between">
                <a href="<?php echo e(route('home.index')); ?>" class="button-confirm">Back</a>
            </div>

            <?php echo $__env->make('auth.partials.copy', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </form>
    </div>
</section>
<style>
    .form {
        --input-focus: #2d8cf0;
        --font-color: #323232;
        --font-color-sub: #666;
        --bg-color: #fff;
        --main-color: #323232;
        padding: 20px;
        background: lightgrey;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        gap: 20px;
        border-radius: 5px;
        border: 2px solid var(--main-color);
        box-shadow: 4px 4px var(--main-color);
        max-width: 400px; /* Reducimos el ancho del contenedor */
    }

    form {
        display: flex;
        flex-direction: column;
        gap: 20px;
        width: 100%;
        align-items: center;
    }

    .title {
        color: var(--font-color);
        font-weight: 900;
        font-size: 20px;
        margin-bottom: 25px;
        text-align: center;
    }

    .title span {
        color: var(--font-color-sub);
        font-weight: 600;
        font-size: 17px;
    }

    .input {
        width: 100%; /* Ajustamos el ancho del input al contenedor */
        height: 40px;
        border-radius: 5px;
        border: 2px solid var(--main-color);
        background-color: var(--bg-color);
        box-shadow: 4px 4px var(--main-color);
        font-size: 15px;
        font-weight: 600;
        color: var(--font-color);
        padding: 5px 10px;
        outline: none;
    }

    .input::placeholder {
        color: var(--font-color-sub);
        opacity: 0.8;
    }

    .input:focus {
        border: 2px solid var(--input-focus);
    }

    .button-confirm {
        width: 120px;
        height: 40px;
        border-radius: 5px;
        border: 2px solid var(--main-color);
        background-color: var(--bg-color);
        box-shadow: 4px 4px var(--main-color);
        font-size: 17px;
        font-weight: 600;
        color: var(--font-color);
        cursor: pointer;
    }
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Yonatan\Documents\Universidad\UTOM\dwi-pf-homeharmony\resources\views/auth/register.blade.php ENDPATH**/ ?>