<?php $__env->startSection('content'); ?>

<?php if($errors->any()): ?>

<div class="alert alert-danger">
    <ul>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <?php if($error =='The name field is required.'): ?>
        <li>The title field is required.</li>
        <?php elseif($error =='The description field is required.'): ?>
        <li>The description field is required.</li>
        <?php elseif($error =='The price field is required.'): ?>
        <li>The price field is required.</li>
        <?php else: ?>
        <li><?php echo e($error); ?></li>
        <?php endif; ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>

<?php endif; ?>


<div class="card">
    <div class="card-header">
        <div class="row">
            <div class="col col-md-6"><b>Article Details</b></div>
            <div class="col col-md-6">
                <div class="col col-md-6">
                    <a href="<?php echo e(route('articles.index')); ?>" class="btn btn-primary btn-sm float-end">View All</a>
                </div>
            </div>
        </div>
    </div>
    <div class="card-body">
        <div class="row mb-3">
            <label class="col-sm-2 col-label-form"><b>Article Name</b></label>
            <div class="col-sm-10">
                <?php echo e($article->title); ?>

            </div>
        </div>
        <div class="row mb-3">
            <label class="col-sm-2 col-label-form"><b>Article Description</b></label>
            <div class="col-sm-10">
                <?php echo e($article->description); ?>

            </div>
        </div>
        <div class="row mb-3">
            <label class="col-sm-2 col-label-form"><b>Article Price</b></label>
            <div class="col-sm-10">
                <?php echo e($article->price); ?>

            </div>
        </div>
        <div class="row mb-4">
            <label class="col-sm-2 col-label-form"><b>Category</b></label>
            <div class="col-sm-10">
                <?php echo e($article->category->name); ?>

            </div>
        </div>
        <div class="row mb-4">
			<label class="col-sm-2 col-label-form"><b>Aticle Image</b></label>
			<div class="col-sm-10">
				<img src="<?php echo e(asset('imagesArticles/' .  $article->article_image)); ?>" width="200" class="img-thumbnail" />
			</div>
		</div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Universidad\UTOM\dwi-pf-homeharmony\resources\views/articles/show.blade.php ENDPATH**/ ?>