<?php $__env->startSection('content'); ?>
    <div class="">
        <?php if(auth()->guard()->check()): ?>
            <h1 class="text-light">Inicio</h1>
            <p class="lead text-light">Usuario autenticado</p>

            <div class="container-fluid p-0" style="background-color: #3B5D50; ">
                <div class="row no-gutters">
                    <div class="col-md-6 d-flex align-items-center">
                        <div class="text-center text-light p-4">
                            <h1>HomeHarmony</h1>
                            <p>
                                En HomeHarmony, creemos que cada espacio cuenta una historia y cada mueble es
                                una pieza esencial en ese relato.
                            </p>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <img src="<?php echo e(url('imagesArticles/couch.png')); ?>" alt="Imagen" class="img-fluid rounded-right" style="border-radius: 10px;">
                    </div>
                </div>
            </div>
            
            
            <div class="rounded">
                <img src="<?php echo e(url('images/xd.png')); ?>" alt="Imagen" class="img-fluid rounded-right" style="border-radius: 10px;">
            </div>
        <?php endif; ?>
        <?php if(auth()->guard()->guest()): ?>
        <div class="container-fluid p-0" style="background-color: #3B5D50; ">
            <div class="row no-gutters">
                <div class="col-md-6 d-flex align-items-center">
                    <div class="text-center text-light p-4">
                        <h1>HomeHarmony</h1>
                        <p>
                            En HomeHarmony, creemos que cada espacio cuenta una historia y cada mueble es
                            una pieza esencial en ese relato.
                        </p>
                    </div>
                </div>
                <div class="col-md-6">
                    <img src="<?php echo e(url('imagesArticles/couch.png')); ?>" alt="Imagen" class="img-fluid rounded-right" style="border-radius: 10px;">
                </div>
            </div>
        </div>
        
        
        <div class="rounded">
            <img src="<?php echo e(url('images/xd.png')); ?>" alt="Imagen" class="img-fluid rounded-right" style="border-radius: 10px;">
        </div>


        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Yonatan\Documents\Universidad\UTOM\dwi-pf-homeharmony\resources\views/home/index.blade.php ENDPATH**/ ?>