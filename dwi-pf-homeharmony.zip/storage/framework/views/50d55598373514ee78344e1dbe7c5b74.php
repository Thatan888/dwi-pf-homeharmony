<?php $__env->startSection('content'); ?>

<?php if($message = Session::get('success')): ?>
<div class="alert alert-success">
    <?php echo e($message); ?>

</div>
<?php endif; ?>

<div class="card">
    <div class="card-header">
        <div class="row">
            <div class="col col-md-6"><b>Articles Data</b></div>
            <div class="col col-md-6">
                <a href="<?php echo e(route('articles.create')); ?>" class="btn btn-success btn-sm float-end">Add</a>
            </div>
        </div>
    </div>
    <div class="card-body">
        <table class="table table-bordered">
            <tr>
                <th>Image</th>
                <th>Article</th>
                <th>Description</th>
                <th>Price</th>
                <th>Category</th>
                <th>Action</th>
            </tr>
            <?php if(count($articles) > 0): ?>
            <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><img src="<?php echo e(asset('imagesArticles/'.$article->article_image)); ?>" width="75" /></td>
                <td><?php echo e($article->title); ?></td>
                <td><?php echo e($article->description); ?></td>
                <td><?php echo e($article->price); ?></td>
                <td><?php echo e($article->category->name); ?></td>
                <td>
                    <form method="post" action="<?php echo e(route('articles.destroy', $article->id)); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <a href="<?php echo e(route('articles.show', $article->id)); ?>" class="btn btn-primary btn-sm">View</a>
                        <a href="<?php echo e(route('articles.edit', $article->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
                        <input type="submit" class="btn btn-danger btn-sm" value="Delete" />
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
            <tr>
                <td colspan="6" class="text-center">No Data Found</td>
            </tr>
            <?php endif; ?>
        </table>
        <?php echo $articles->links(); ?>

    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\UNIVERSIDAD - ALL\9no Cuatri\Proyectos\UTOM\dwi-pf-homeharmony\resources\views/articles/index.blade.php ENDPATH**/ ?>