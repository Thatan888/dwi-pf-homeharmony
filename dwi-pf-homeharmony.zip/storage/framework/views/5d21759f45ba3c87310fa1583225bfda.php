<?php $__env->startSection('content'); ?>

<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($error == 'The name field is required.'): ?>
                    <li>The category name field is required.</li>
                <?php elseif($error == 'The description field is required.'): ?>
                    <li>The category description field is required.</li>
                <?php else: ?>
                    <li><?php echo e($error); ?></li>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<div class="card" style="background-color: #bfe9bf;">
    <div class="card-header" style="background-color: #BFE9BF;">
        <div class="row">
            <div class="col col-md-6 fs-1"><b>Furniture Category Details</b></div>
            <div class="col col-md-6 text-end">
                <a href="<?php echo e(route('categories.index')); ?>" class="custom-link">Back</a>
            </div>
        </div>
    </div>
    <div class="card-body">
        <div class="container">
            <div class="row mb-3">
                <div class="col-md-4"><strong>Category Name:</strong></div>
                <div class="col-md-8"><?php echo e($category->name); ?></div>
            </div>
            <div class="row mb-3">
                <div class="col-md-4"><strong>Category Description:</strong></div>
                <div class="col-md-8"><?php echo e($category->description); ?></div>
            </div>
        </div>
    </div>
</div>

<style>
    .custom-link {
        color: #ecf0f1;
        font-size: 17px;
        background-color: #3B5D50;
        border: 1px solid #ffffff;
        border-radius: 5px;
        cursor: pointer;
        padding: 10px;
        box-shadow: 0px 6px 0px #578775;
        transition: all 0.1s;
        display: inline-block;
    }

    .custom-link:active {
        box-shadow: 0px 2px 0px #3B5D50;
        position: relative;
        top: 2px;
    }

    .custom-link {
        color: #ecf0f1;
        text-decoration: none;
    }

    .custom-link:hover {
        color: #ecf0f1;
        text-decoration: none;
    }
</style>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Yonatan\Documents\Universidad\UTOM\dwi-pf-homeharmony\resources\views/categories/show.blade.php ENDPATH**/ ?>