<?php $__env->startSection('content'); ?>

<div class="card">
	<div class="card-header">Edit article</div>
	<div class="card-body">
		<form method="post" action="<?php echo e(route('articles.update', $article->id)); ?>" enctype="multipart/form-data">
			<?php echo csrf_field(); ?>
			<?php echo method_field('PUT'); ?>
			<div class="row mb-3">
				<label class="col-sm-2 col-label-form">Article Name</label>
				<div class="col-sm-10">
					<input type="text" name="title" class="form-control" value="<?php echo e($article->title); ?>" />
				</div>
			</div>
			<div class="row mb-3">
				<label class="col-sm-2 col-label-form">Article Description</label>
				<div class="col-sm-10">
					<textarea type="text" name="description" class="form-control" rows="3"><?php echo e($article->description); ?></textarea>
				</div>
			</div>
			<div class="row mb-3">
				<label class="col-sm-2 col-label-form">Item Price</label>
				<div class="col-sm-10">
					<input type="float" name="price" class="form-control" value="<?php echo e($article->price); ?>" />
				</div>
			</div>
			<div class="row mb-3">
				<label class="col-sm-2 col-label-form">Article Category</label>
				<div class="col-sm-10">
					<select name="category_id" class="form-control">
						<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<option value="<?php echo e($category->id); ?>" <?php if($category->id == $article->category_id): ?> selected <?php endif; ?>><?php echo e($category->name); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
				</div>
			</div>
            <div class="row mb-4">
				<label class="col-sm-2 col-label-form">Article Image</label>
				<div class="col-sm-10">
					<input type="file" name="article_image" />
					<br />
					<img src="<?php echo e(asset('imagesArticles/' . $article->article_image)); ?>" width="100" class="img-thumbnail" />
					<input type="hidden" name="hidden_article_image" value="<?php echo e($article->article_image); ?>" />
				</div>
			</div>
			<div class="text-center">
				<input type="hidden" name="hidden_id" value="<?php echo e($article->id); ?>" />
				<input type="submit" class="btn btn-primary" value="Edit" />
			</div>
		</form>
	</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\UNIVERSIDAD - ALL\9no Cuatri\Proyectos\UTOM\dwi-pf-homeharmony\resources\views/articles/edit.blade.php ENDPATH**/ ?>