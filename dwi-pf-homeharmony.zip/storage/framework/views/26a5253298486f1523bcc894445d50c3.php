<p class="mt-5 mb-3 text-muted">&copy; <?php echo e(date('Y')); ?></p>
<?php /**PATH C:\Universidad\UTOM\dwi-pf-homeharmony\resources\views/auth/partials/copy.blade.php ENDPATH**/ ?>