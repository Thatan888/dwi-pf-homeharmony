<?php $__env->startSection('content'); ?>
    <section class="vh-100" style="background-color: #000000;">
        <div class="container py-5 h-100">
            <div class="row d-flex justify-content-center align-items-center h-100">
                <div class="col col-xl-10">
                    <div class="card" style="border-radius: 1rem;">
                        <div class="row g-0">
                            <div class="col-md-6 col-lg-5 d-none d-md-block">
                                <img src="<?php echo e(url('images/books-3733892_1280.jpg')); ?>" alt="login form" class="img-fluid"
                                    style="border-radius: 1rem 0 0 1rem;" />
                            </div>
                            <div class="col-md-6 col-lg-7 d-flex align-items-center">
                                <div class="card-body p-4 p-lg-5 text-black">

                                    <form method="post" action="<?php echo e(route('login.perform')); ?>">
                                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />
                                        

                                        <h5 class="fw-normal mb-3 pb-3" style="letter-spacing: 1px;">Sign into your account
                                        </h5>

                                        <?php echo $__env->make('layouts.partials.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                                        <div data-mdb-input-init class="form-group form-floating form-outline mb-4">
                                            <input type="text" id="form2Example17" value="<?php echo e(old('username')); ?>"
                                                placeholder="Username" class="form-control form-control-lg" name="username"
                                                required="required" autofocus>
                                            <label class="form-label" for="floatingName form2Example17">Email
                                                address</label>
                                            <?php if($errors->has('username')): ?>
                                                <span class="text-danger text-left"><?php echo e($errors->first('username')); ?></span>
                                            <?php endif; ?>
                                        </div>

                                        <div data-mdb-input-init class="form-group form-floating form-outline mb-4">
                                            <input type="password" class="form-control form-control-lg" name="password"
                                                value="<?php echo e(old('password')); ?>" placeholder="Password"
                                                required="required id="form2Example27"">
                                            <label class="form-label" for="form2Example27 floatingPassword">Password</label>
                                            <?php if($errors->has('password')): ?>
                                                <span class="text-danger text-left"><?php echo e($errors->first('password')); ?></span>
                                            <?php endif; ?>
                                        </div>

                                        <div class="pt-1 mb-4">
                                            <button class="w-100 btn btn-lg btn-primary" type="submit">Login</button>
                                            <a href="<?php echo e(route('home.index')); ?>" class="w-100 btn btn-lg mt-2 btn-secondary">Back</a>
                                        </div>
                                        <?php echo $__env->make('auth.partials.copy', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        <p class="mb-5 pb-lg-2" style="color: #393f81;">Don't have an account? <a
                                                href="<?php echo e(route('register.perform')); ?>" style="color: #393f81;">Register
                                                here</a></p>
                                    </form>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\UNIVERSIDAD - ALL\9no Cuatri\Proyectos\UTOM\dwi-pf-homeharmony\resources\views/auth/login.blade.php ENDPATH**/ ?>