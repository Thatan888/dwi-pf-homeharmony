<?php $__env->startSection('content'); ?>

<?php if($errors->any()): ?>
<div class="alert alert-danger">
    <ul>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($error == 'The name field is required.'): ?>
        <li>The category name field is required.</li>
        <?php elseif($error == 'The description field is required.'): ?>
        <li>The category description field is required.</li>
        <?php else: ?>
        <li><?php echo e($error); ?></li>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php endif; ?>

<div class="card">
    <div class="card-header">
        <div class="row">
            <div class="col col-md-6"><b>Furniture Category Details</b></div>
            <div class="col col-md-6">
                <div class="col col-md-6">
                    <a href="<?php echo e(route('categories.index')); ?>" class="btn btn-primary btn-sm float-end">View All</a>
                </div>
            </div>
        </div>
    </div>
    <div class="card-body">
        <div class="row mb-3">
            <label class="col-sm-2 col-label-form"><b>Category Name</b></label>
            <div class="col-sm-10">
                <?php echo e($category->name); ?>

            </div>
        </div>
        <div class="row mb-3">
            <label class="col-sm-2 col-label-form"><b>Category Description</b></label>
            <div class="col-sm-10">
                <?php echo e($category->description); ?>

            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\UNIVERSIDAD - ALL\9no Cuatri\Proyectos\UTOM\dwi-pf-homeharmony\resources\views/categories/show.blade.php ENDPATH**/ ?>