@extends('layouts.app-master')

@section('content')
    <div class="">
        @auth
            <h1 class="text-light">Inicio</h1>
            <p class="lead text-light">Usuario autenticado</p>

            <div class="container-fluid p-0" style="background-color: #3B5D50; ">
                <div class="row no-gutters">
                    <div class="col-md-6 d-flex align-items-center">
                        <div class="text-center text-light p-4">
                            <h1>HomeHarmony</h1>
                            <p>
                                En HomeHarmony, creemos que cada espacio cuenta una historia y cada mueble es
                                una pieza esencial en ese relato.
                            </p>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <img src="{{ url('imagesArticles/couch.png') }}" alt="Imagen" class="img-fluid rounded-right" style="border-radius: 10px;">
                    </div>
                </div>
            </div>
            
            
            <div class="rounded">
                <img src="{{ url('images/xd.png') }}" alt="Imagen" class="img-fluid rounded-right" style="border-radius: 10px;">
            </div>
        @endauth
        @guest
        <div class="container-fluid p-0" style="background-color: #3B5D50; ">
            <div class="row no-gutters">
                <div class="col-md-6 d-flex align-items-center">
                    <div class="text-center text-light p-4">
                        <h1>HomeHarmony</h1>
                        <p>
                            En HomeHarmony, creemos que cada espacio cuenta una historia y cada mueble es
                            una pieza esencial en ese relato.
                        </p>
                    </div>
                </div>
                <div class="col-md-6">
                    <img src="{{ url('imagesArticles/couch.png') }}" alt="Imagen" class="img-fluid rounded-right" style="border-radius: 10px;">
                </div>
            </div>
        </div>
        
        
        <div class="rounded">
            <img src="{{ url('images/xd.png') }}" alt="Imagen" class="img-fluid rounded-right" style="border-radius: 10px;">
        </div>


        @endguest
    </div>
@endsection
